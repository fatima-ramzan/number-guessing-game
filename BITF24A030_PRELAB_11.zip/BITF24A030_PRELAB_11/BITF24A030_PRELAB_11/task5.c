#include <stdio.h>
int main() {
    int a[5][4], valid = 1;
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 4; j++)
            scanf("%d", &a[i][j]);
    for (int i = 0; i < 5; i++) {
        int count = 0;
        for (int j = 0; j < 4; j++)
            if (a[i][j] == 1) count++;
        if (count != 1) {
            valid = 0;
            break;
        }
    }
    if (valid) printf("Valid OMR Sheet\n");
    else printf("Invalid OMR Sheet\n");
    return 0;
}