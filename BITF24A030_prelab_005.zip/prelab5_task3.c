#include<stdio.h>
float convert_pkr_to_foreign(float amount,float rate)
{
    return amount/rate;
}
int main()
{
    float amount,rate;
    int currency;
    printf("Enter amount in PKR:");
    scanf("%f",&amount);
    printf("Select conversion:\n1.USD\n2.EUR\n3.GBP\n CHOICE:");
    scanf("%d",&currency);
    switch (currency)
    {
    case 1:
       rate=280.0;
        break;
    case 2:
       rate=300.0;
       break;
    case 3:
       rate=350.0;
       break;
    default:
       printf("Invalid input!\n");
        break;
    }
    printf("Converted amount: %.2f\n",convert_pkr_to_foreign(amount,rate));
    return 0;
}