#include<stdio.h>
void show_exchange_rates()
{
    printf("Exchange Rates:\n");
    printf("1 USD =280PKR\n");
    printf("1 EUR =300 PKR\n");
    printf("1 GBP =350 PKR\n");
}
int main()
{
    show_exchange_rates();
    return 0;
}