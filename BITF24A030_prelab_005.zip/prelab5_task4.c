#include<stdio.h>
 float convert_foreign_to_pkr(float amount,float rate)
    {
        return amount*rate;
    }
int main()
{
    float amount,rate;
    int currency;
    printf("Enter amount in foreign currency:");
    scanf("%f",&amount);
    printf("Select conversion:\n1.USD\n2.EUR\n3.GBP\nCHOICE:");
    scanf("%d",&currency);
    switch (currency)
    {
       case 1:
       rate =280.0;
       break;
       case 2:
       rate= 300.0;
       break;
       case 3:
       rate =350.0;
        break;
    default:
    printf("Invalid selection!");
        return 1;
    }
    printf("Converted amount:%.2f",convert_foreign_to_pkr(amount,rate));
    return 0;
}
    
