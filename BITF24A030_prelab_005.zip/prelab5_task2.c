#include<stdio.h>
float get_exchange_rate(int option)
{
    switch (option)
    {
    case 1:
       return 280.0;
    case 2:
       return 300.0;
    case 3:
       return 350;
    default:
       return -1.0;
    }
}
int main()
{
    int choice;
    printf("Enter currency option (1: USD , 2. EUR ,3:GBP):");
    scanf("%d",&choice);
    float rate= get_exchange_rate(choice);
    if (rate == -1)
    {
       printf("Invalid selection!\n");
    }
    else
    {
        printf("Exchange rate: %.2f PKR\n",rate);
    }
    return 0;
}