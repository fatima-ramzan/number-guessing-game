#include<stdio.h>
    void show_exchange_rates()
{
    printf("Exchange Rates:\n");
    printf("1 USD =280PKR\n");
    printf("1 EUR =300 PKR\n");
    printf("1 GBP =350 PKR\n");
}
float get_exchange_rate(int option)
{
    switch (option)
    {
    case 1:
       return 280.0;
    case 2:
       return 300.0;
    case 3:
       return 350;
    default:
       return -1.0;
    }
}
    float convert_pkr_to_foreign(float amount,float rate)
    {
        return amount/rate;
    }
    float convert_foreign_to_pkr(float amount,float rate)
    {
        return amount*rate;
    }  
int main()
{
    int choice;
    do
    {
       printf("\n CURRENCY CONVERTER\n");
       printf("1.Show Exchange Rates\n");
       printf("2.Convert PKR to Foreign Currency\n");
       printf("3.Convert Foreign Currency to PKR\n");
       printf("4.Exit\n");
       printf("Enter your Choice:");
       scanf("%d",&choice);
       if (choice == 1)
       {
        show_exchange_rates();
       }
       else if (choice == 2)
       {
        float amount,rate;
        int currency;
        printf("Enter amount in PKR:");
        scanf("%f",&amount);
        printf("Select conversion:\n1.USD\n2.EUR\n3.GBP\n CHOICE:");
        scanf("%d",&currency);
        rate=get_exchange_rate(currency);
        if (rate == -1)
        {
           printf("Invalid selection!\n");
        }
        else
        {
            printf("Converted amount: %.2f\n",convert_pkr_to_foreign(amount,rate));
        } 
       }
       else if (choice ==3)
       {
         float amount,rate;
         int currency;
         printf("Enter amount in foreign currency:");
         scanf("%f",&amount);
         printf("Select conversion:\n1.USD\n2.EUR\n3.GBP\nCHOICE:");
         scanf("%d",&currency);
    rate =get_exchange_rate(currency);
    if (rate == -1)
    {
       printf("Invalid selection!\n");
    }
    else
    {
        printf("Converted amount:%.2f",convert_foreign_to_pkr(amount,rate));
    }
}
    else if (choice == 4)
    {
       printf("Exiting....\n");
    }
    else
    {
    printf("Invalid choice! Please enter again:");
    }      
    } while (choice!=4);
    return 0;
}